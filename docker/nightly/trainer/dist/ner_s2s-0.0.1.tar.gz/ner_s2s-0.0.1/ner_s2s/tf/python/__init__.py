from ner_s2s.tf.python.keras import activations
