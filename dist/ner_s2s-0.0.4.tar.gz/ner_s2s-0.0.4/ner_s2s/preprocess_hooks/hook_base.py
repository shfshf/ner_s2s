class HookBase(object):
    def __call__(self, sentence):
        return NotImplementedError
