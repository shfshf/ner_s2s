__version__ = "0.0.1"

# for custom keras object auto discover
from ner_s2s import tf
